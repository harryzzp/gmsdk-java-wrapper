//////////////////////////////////////////////////////////////////////////
//空策略

#include <iostream>
#include "strategy.h"

using namespace std;

class MyStrategy :public Strategy
{
public:
	MyStrategy() {}
	~MyStrategy(){}

	//重写on_init事件，进行策略开发
	void on_init()
	{
		cout << "on_init" << endl;
		cout << "hello world" << endl;

		return;
	}

private:
};

int main(int argc, char *argv[])
{
	MyStrategy s;
	s.set_strategy_id("{{strategyId}}");
	s.set_token("{{token}}");
	s.set_mode(MODE_BACKTEST);
	s.set_backtest_config("2017-07-11 14:20:00", "2017-07-11 15:30:00",
		1000000, 1, 0, 0, 0, 1);
	s.run();
	cout << "`press any key to exit!`" << endl;
	getchar();
	return 0;
}